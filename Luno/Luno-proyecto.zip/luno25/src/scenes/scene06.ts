import {lunoScene} from '../stage';
export default lunoScene(5);
