import {lunoScene} from '../stage';
export default lunoScene(1);
