export const C={ink:'#49324f',ivory:'#fff0df',blue:'#adc8e9',blueShade:'#90add3',orange:'#f7a06d',lav:'#c0aad1',mint:'#bfdcca',cream:'#fff0d4',pink:'#f0b6b5',night:'#413753'};
export const clamp=(v:number,a=0,b=1)=>Math.max(a,Math.min(b,v));
export const ease=(v:number)=>{v=clamp(v);return v*v*(3-2*v);};
export const lerp=(a:number,b:number,t:number)=>a+(b-a)*t;
export const pop=(v:number)=>{v=clamp(v);return 1-Math.pow(1-v,3)*Math.cos(v*5);};
export class Pen {
  constructor(public g:CanvasRenderingContext2D){}
  box(x:number,y:number,w:number,h:number,fill:string,rad=20,stroke=C.ink,lw=5){const g=this.g;g.beginPath();g.roundRect(x,y,w,h,rad);g.fillStyle=fill;g.fill();if(stroke){g.strokeStyle=stroke;g.lineWidth=lw;g.stroke();}}
  ellipse(x:number,y:number,rx:number,ry:number,fill:string,stroke=C.ink,lw=5){const g=this.g;g.beginPath();g.ellipse(x,y,rx,ry,0,0,Math.PI*2);g.fillStyle=fill;g.fill();if(stroke){g.strokeStyle=stroke;g.lineWidth=lw;g.stroke();}}
  line(points:number[][],fill=C.ink,lw=5){const g=this.g;g.beginPath();g.moveTo(...points[0] as [number,number]);for(const [x,y]of points.slice(1))g.lineTo(x,y);g.strokeStyle=fill;g.lineWidth=lw;g.lineCap='round';g.lineJoin='round';g.stroke();}
  path(points:number[][],fill:string,stroke=C.ink,lw=5){const g=this.g;g.beginPath();g.moveTo(...points[0] as [number,number]);for(const [x,y]of points.slice(1))g.lineTo(x,y);g.closePath();g.fillStyle=fill;g.fill();if(stroke){g.strokeStyle=stroke;g.lineWidth=lw;g.stroke();}}
  text(txt:string,x:number,y:number,size=40,fill=C.ink,weight=700,align:CanvasTextAlign='center'){const g=this.g;g.font=`${weight} ${size}px LunoSans, sans-serif`;g.textAlign=align;g.textBaseline='middle';g.fillStyle=fill;g.fillText(txt,x,y);}
  lines(txt:string,x:number,y:number,width:number,size=36,fill=C.ink,lineHeight=1.32){const g=this.g;g.font=`700 ${size}px LunoSans, sans-serif`;const words=txt.split(/\s+/);const lines:string[]=[];let line='';for(const word of words){const next=line?`${line} ${word}`:word;if(g.measureText(next).width>width&&line){lines.push(line);line=word;}else line=next;}if(line)lines.push(line);lines.forEach((l,i)=>this.text(l,x,y+i*size*lineHeight,size,fill));return lines.length;}
  local(x:number,y:number,k:number,fn:()=>void,rot=0){const g=this.g;g.save();g.translate(x,y);g.rotate(rot);g.scale(k,k);fn();g.restore();}
  alpha(a:number,fn:()=>void){this.g.save();this.g.globalAlpha*=clamp(a);fn();this.g.restore();}
  star(x:number,y:number,r=15,color=C.orange){const pts=[];for(let i=0;i<8;i++){const a=i*Math.PI/4;const rr=i%2?r*.3:r;pts.push([x+Math.cos(a)*rr,y+Math.sin(a)*rr]);}this.path(pts,color,'');}
}
export type Expression='happy'|'confused'|'worried'|'surprised'|'thinking'|'proud';
export interface Rig {x:number;y:number;k?:number;time:number;expression?:Expression;walk?:number;wave?:number;phone?:boolean;point?:number;celebrate?:number;tilt?:number;seated?:boolean;crossed?:boolean;typing?:boolean;scratch?:boolean;role?:'luno'|'mom'|'baker';}

/** Layered, reusable character rig. All joints are animated in local coordinates. */
export function luno(p:Pen,o:Rig){const t=o.time,walk=o.walk??0,phase=t*7.5;const bob=Math.sin(phase*2)*3*walk+Math.sin(t*2.2)*2;
 const role=o.role??'luno',mom=role==='mom',baker=role==='baker';const hoodie=mom?'#c5a7cd':baker?'#e8b98d':C.blue;
 p.local(o.x,o.y+bob,o.k??1,()=>{
  p.ellipse(0,252,93,14,'#775775','',0);
  // Two articulated leg chains, then white sneakers.
  for(const side of [-1,1]){const hip=side*35;const stride=Math.sin(phase+(side<0?0:Math.PI))*49*walk;const lift=Math.max(0,Math.cos(phase+(side<0?0:Math.PI)))*22*walk;
   p.line([[hip,68],[hip+stride*.45+(o.seated?40:0),150-lift*.35],[hip+stride,220-lift]],C.ink,19);
   p.box(hip+stride-26,215-lift,62,33,C.ivory,15,C.ink,4);p.line([[hip+stride-19,237-lift],[hip+stride+30,237-lift]],C.blueShade,4);
  }
  // Hood and torso stay identical across all Luno scenes.
  p.ellipse(0,-78,99,62,hoodie,C.ink,5);
  p.path([[-69,-91],[-92,56],[-74,91],[76,91],[91,54],[68,-91],[0,-73]],hoodie);
  p.line([[-72,79],[75,79]],C.blueShade,4);
  p.path([[-40,20],[-56,60],[54,60],[40,20]],hoodie,C.blueShade,4);
  p.line([[-57,-81],[-22,-62],[0,-76],[24,-61],[60,-82]],C.ink,4);
  // IK-inspired elbow construction keeps sleeves connected during gestures.
  const arm=(side:number)=>{const sx=side*70,sy=-58;let hx=side*101,hy=79;
   hx+=Math.sin(phase+(side<0?Math.PI:0))*27*walk;hy-=Math.cos(phase)*7*walk;
   if(o.phone&&side===1){hx=81;hy=-97;}
   if(o.wave&&side===1){hx=131+Math.sin(t*11)*14*o.wave;hy=-143-22*o.wave;}
   if(o.point&&side===1){hx=176;hy=-30-65*o.point;}
   if(o.celebrate){hx=side*(127+Math.sin(t*8)*7);hy=-130-o.celebrate*25;}
   if(o.expression==='thinking'&&side===1){hx=48;hy=-136;}
   if(o.crossed){hx=-side*45;hy=-4;}
   if(o.typing){hx=(side===1?178:121)+Math.sin(t*24+side)*5;hy=135+Math.sin(t*27+side*2)*6;}
   if(o.scratch&&side===1){hx=105+Math.sin(t*12)*5;hy=-218+Math.sin(t*12)*7;}
   const ex=(sx+hx)*.5+side*29,ey=(sy+hy)*.5+15;
   p.line([[sx,sy],[ex,ey],[hx,hy]],C.ink,39);p.line([[sx,sy],[ex,ey],[hx,hy]],hoodie,29);
   p.ellipse(hx,hy+5,18,23,C.ivory,C.ink,4);
   if(o.phone&&side===1)phone(p,hx+8,hy-33,.36,0);
  };
  arm(-1);
  if(role==='luno'){
   p.line([[-65,-86],[73,44]],C.ink,20);p.line([[-65,-86],[73,44]],C.orange,12);
   p.box(56,14,62,84,C.orange,18,C.ink,4);p.box(62,20,50,35,'#ffb482',12,C.ink,3);p.ellipse(91,52,4,5,C.ink,'');
  }else if(baker){p.path([[-48,-63],[-63,89],[64,89],[48,-63]],C.cream);p.box(-33,15,66,41,C.cream,6,C.ink,3);}
  arm(1);
  // Head rotation, eye direction, blinks and six mouth/brow expressions.
  p.local(0,-208,1,()=>{
   if(mom)p.ellipse(0,-3,125,122,'#6d4d69');
   p.ellipse(0,0,118,116,C.ivory,C.ink,5);
   p.alpha(.5,()=>p.g.strokeStyle=C.pink); // soft chin contour
   const e=o.expression??'happy';const look=e==='thinking'?13:e==='confused'?-9:Math.sin(t*.8)*3;
   const blink=t%3.7<.14;
   for(const side of [-1,1]){const x=side*43+look;
    if(blink||e==='proud')p.line([[x-9,7],[x,2],[x+9,7]],C.ink,5);
    else p.ellipse(x,9,e==='surprised'?11:8,e==='surprised'?15:10,C.ink,'');
    if(e==='worried')p.line([[x-13,-17+(side<0?7:-3)],[x+13,-17+(side<0?-3:7)]],C.ink,4);
    if(e==='confused')p.line([[x-13,-22+(side<0?-8:5)],[x+13,-22+(side<0?-2:1)]],C.ink,4);
   }
   const g=p.g;g.beginPath();g.lineWidth=5;g.strokeStyle=C.ink;
   if(e==='surprised')p.ellipse(1,48,12,17,C.ink,'');
   else if(e==='worried'){g.moveTo(-13,52);g.quadraticCurveTo(0,35,15,52);g.stroke();}
   else if(e==='thinking'||e==='confused')p.line([[-12,48],[11,e==='thinking'?48:43]],C.ink,5);
   else{g.moveTo(-18,41);g.quadraticCurveTo(0,67,20,40);g.stroke();}
   if(e==='happy'||e==='proud'){p.ellipse(-73,39,13,5,'#f3c9bd','');p.ellipse(73,39,13,5,'#f3c9bd','');}
   if(mom){p.path([[-113,-26],[-107,-82],[-60,-118],[13,-123],[90,-91],[113,-35],[47,-84],[-19,-47],[-79,-52]],'#6d4d69');}
   if(baker){p.box(-102,-140,203,58,C.cream,18);for(const x of [-65,0,65])p.ellipse(x,-145,44,36,C.cream);}
  },o.tilt??Math.sin(t*.9)*.025);
 });
}

export function phone(p:Pen,x:number,y:number,k=1,screen=0){p.local(x,y,k,()=>{p.box(-70,-125,140,250,C.ink,24,C.ink,4);p.box(-61,-110,122,213,screen===1?'#fff4da':'#e9e7f1',15,'');p.box(-20,-116,40,9,C.ink,5,'');p.ellipse(0,114,7,7,'#b6a3c3','');if(screen===0){p.box(-44,-72,88,45,C.blue,8,'');p.box(-44,-13,57,10,C.lav,4,'');p.box(-44,8,88,9,C.lav,4,'');p.box(-44,34,69,9,C.orange,4,'');}});}
export function bread(p:Pen,x:number,y:number,k=1){p.local(x,y,k,()=>{p.ellipse(0,3,54,33,'#d79a63');p.ellipse(0,-6,53,31,'#f2c381',C.ink,4);for(const xx of [-22,0,22])p.line([[xx-4,-24],[xx+5,-5]],'#fff0cf',5);});}
export function headphones(p:Pen,x:number,y:number,k=1){p.local(x,y,k,()=>{const g=p.g;g.beginPath();g.arc(0,0,48,Math.PI,Math.PI*2);g.strokeStyle=C.ink;g.lineWidth=15;g.stroke();g.beginPath();g.arc(0,0,48,Math.PI,Math.PI*2);g.strokeStyle=C.blue;g.lineWidth=8;g.stroke();p.box(-59,-8,25,54,C.blue,10);p.box(34,-8,25,54,C.blue,10);});}
export function coin(p:Pen,x:number,y:number,k=1,label='$'){p.local(x,y,k,()=>{p.ellipse(0,0,36,36,'#f2c77f',C.ink,4);p.ellipse(0,0,27,27,'#f8dba2','#dba45f',3);p.text(label,0,1,20,C.ink);});}
export function sparkles(p:Pen,t:number,x=540,y=950,n=16){for(let i=0;i<n;i++){const a=i*2.399+t*.18,r=150+(i%5)*43;const drift=Math.sin(t*2+i)*15;p.star(x+Math.cos(a)*r,y+Math.sin(a)*r+drift,8+(i%3)*4,[C.orange,C.lav,C.mint][i%3]);}}
export function poster(p:Pen,x:number,y:number,k=1,variant=0,bad=false){p.local(x,y,k,()=>{p.box(-128,-168,256,336,bad?'#dfc6b1':variant===1?'#eee7f3':C.cream,16,C.ink,5);if(bad){for(let i=0;i<7;i++)p.local(-76+i%3*50,-102+i*30,1,()=>p.text(['P','A','N','2','X','1','!'][i],0,0,34,[C.lav,C.orange,C.ink][i%3]),(i%2?1:-1)*.25);p.line([[-87,92],[70,63],[-43,123]],'#8c8296',7);}else{p.box(-108,-149,216,38,variant===1?C.lav:C.orange,8,'');p.text('PAN DE CASA',0,-129,20);bread(p,0,-40,1.2);p.text('RECIÉN HECHO',0,26,17);p.text('$2',0,72,53);p.line([[-82,109],[82,109]],C.orange,3);p.text('CALLE LAS FLORES 25',0,133,13);}});}
export function invitation(p:Pen,x:number,y:number,k=1){p.local(x,y,k,()=>{p.box(-136,-170,272,340,'#eee3f0',18);for(let j=0;j<10;j++)p.star(-100+j%3*95,-137+Math.floor(j/3)*92,7,[C.orange,C.mint,C.blue][j%3]);p.text('¡ESTÁS',0,-90,31);p.text('INVITADO!',0,-47,31);p.box(-43,22,86,71,C.orange,12);p.box(-50,14,100,19,C.cream,7);for(let i=-1;i<=1;i++)p.line([[i*20,-8],[i*20,12]],C.ink,4);p.text('SÁBADO · 4 PM',0,125,16);});}
export function bubble(p:Pen,x:number,y:number,txt:string,w=330){p.box(x-w/2,y-45,w,90,C.cream,25);p.path([[x-28,y+43],[x-42,y+72],[x+7,y+43]],C.cream);p.lines(txt,x,y-6,w-35,24);}
