import story from './story.json';
import {C,Pen,clamp,ease,lerp,pop,luno,phone,coin,bread,poster,invitation,headphones,bubble,sparkles, type Expression} from './art';
export {story};
export const WIDTH=1080,HEIGHT=1920,FPS=30,DURATION=120;

function city(p:Pen,t:number,offset=0){const g=p.g;const sky=g.createLinearGradient(0,0,0,1500);sky.addColorStop(0,'#f8b8a6');sky.addColorStop(.5,'#f7cfb3');sky.addColorStop(1,'#b1a1c9');g.fillStyle=sky;g.fillRect(0,0,1080,1920);
 p.ellipse(805-offset*.15,557,111,111,'#ffe7b0','');
 for(let layer=0;layer<2;layer++)for(let i=-2;i<12;i++){const width=98+((i+12)*37)%49,x=i*135-(offset*(layer?.6:.22))%135,y=660+((i+30)*83)%220+layer*125;p.box(x,y,width,600,layer?'#ae95b7':'#c5a0bb',6,'');if(layer)for(let col=0;col<3;col++)for(let row=0;row<4;row++)p.box(x+17+col*24,y+30+row*54,10,23,'#d8b7ce',2,'');}
 p.box(0,1300,1080,620,'#c2a5bb',0,'');p.box(0,1330,1080,29,'#b293ac',0,'');
 for(let i=-2;i<9;i++)p.line([[i*205-offset%205,1365],[540+(i-3)*340-offset%205,1920]],'#af91aa',3);
 for(let y=1430;y<1920;y+=100)p.line([[0,y],[1080,y]],'#b599b0',3);
 p.line([[70-offset%1300,1160],[70-offset%1300,661]],C.ink,9);p.box(43-offset%1300,610,54,86,C.cream,16,C.ink,5);
}
function room(p:Pen,t:number){p.box(0,0,1080,1920,'#e3d5e8',0,'');p.box(0,440,1080,950,'#d6c6e0',0,'');
 p.box(670,485,332,475,'#a398c0',22);p.box(687,502,298,439,'#f6c8b1',13,'');p.ellipse(916,602,58,58,'#ffe5b1','');
 for(let i=0;i<4;i++)p.box(690+i*78,700+i%2*70,73,239-i%2*70,'#b29cc3',5,'');
 p.line([[835,501],[835,944]],C.ink,7);p.line([[687,723],[985,723]],C.ink,7);
 p.box(75,550,256,202,C.cream,15);p.text('UNA IDEA',203,615,27);p.text('A LA VEZ.',203,657,27,C.orange);
 p.box(52,1030,325,24,'#b7959f',6);for(let i=0;i<5;i++)p.box(81+i*47,955-(i%2)*32,35,73+(i%2)*32,[C.blue,C.lav,C.mint,C.orange,C.cream][i],5);
 p.box(0,1410,1080,510,'#bd9fac',0,'');p.line([[0,1410],[1080,1410]],C.ink,6);
}
function bakery(p:Pen,t:number,inside=false){if(!inside){city(p,t);p.box(120,630,840,730,'#f7dfbd',24);p.box(90,590,900,126,'#be8ca0',16);p.text('PAN DE CASA',540,651,54,C.cream);
  for(let i=0;i<9;i++)p.box(110+i*96,709,96,91,i%2?C.cream:C.orange,6,C.ink,3);
  p.box(667,830,225,517,'#b6a4c5',16);p.box(683,846,193,265,'#e1c3ce',9);p.ellipse(858,1164,8,8,C.cream);
  p.box(183,833,398,301,'#e8c3af',14);for(let j=0;j<4;j++)bread(p,235+j%2*173,920+Math.floor(j/2)*128,.95);
  p.box(182,1151,401,76,'#c69892',10);p.text('RECIÉN HORNEADO',384,1189,25,C.cream);
 }else{p.box(0,0,1080,1920,'#f5deca',0,'');p.box(0,475,1080,885,'#ead1b9',0,'');
  for(let y=690;y<=940;y+=250){p.box(70,y,940,24,'#b8857d',6);for(let i=0;i<6;i++)bread(p,140+i*163,y-51,.82);}
  p.box(0,1330,1080,590,'#c4a4ae',0,'');p.box(52,1378,976,158,'#c49388',18);p.box(30,1351,1020,52,'#e7b991',13);
 }}
function desk(p:Pen){p.box(82,1421,915,50,'#dda98c',15);p.box(125,1469,38,245,'#b68a87',8);p.box(916,1469,38,245,'#b68a87',8);}
function laptop(p:Pen,x:number,y:number,k=1){p.local(x,y,k,()=>{p.box(-178,-202,356,220,'#7d799b',20);p.box(-161,-186,322,180,'#f1eaf3',10,'');p.box(-207,17,414,22,'#b5a9c4',9);p.box(-72,17,144,8,'#8a80a3',3,'');for(let j=0;j<3;j++)p.ellipse(-142+j*15,-171,4,4,[C.orange,C.lav,C.mint][j],'');});}
function searchWindow(p:Pen,x:number,y:number,txt:string,sub:string,k=1,bad=false){p.local(x,y,k,()=>{p.box(-210,-85,420,170,bad?'#f6d6d0':'#f4edf4',18);p.box(-210,-85,420,39,bad?'#d090a2':C.blue,16,'');p.text('×',178,-66,33);p.lines(txt,0,-7,370,26);p.text(sub,0,49,19,bad?'#9b4e69':'#8c7ba0');});}
function badge(p:Pen,x:number,y:number,txt:string,k=1,color=C.mint){p.local(x,y,k,()=>{p.box(-155,-43,310,86,color,40,C.ink,4);p.text(txt,0,1,34);});}
function bulb(p:Pen,x:number,y:number,k=1){p.local(x,y,k,()=>{p.ellipse(0,-7,36,42,'#ffe39f');p.box(-18,26,36,29,C.lav,7);p.line([[-12,38],[12,38]],C.ink,3);for(let i=0;i<7;i++){const a=i*Math.PI/4-Math.PI/4;p.line([[Math.cos(a)*57,Math.sin(a)*57-7],[Math.cos(a)*70,Math.sin(a)*70-7]],C.orange,5);}});}
function notebook(p:Pen,x:number,y:number,k=1){p.local(x,y,k,()=>{p.box(-150,-190,300,380,C.cream,20);for(let i=0;i<6;i++){p.box(-159,-150+i*55,26,12,C.lav,5);p.line([[-117,-100+i*41],[118,-100+i*41]],'#ddc9bb',2);}p.text('ENCARGO',0,-141,28);p.text('Diseño de cartel',0,-58,23);p.text('S/15',0,3,54);p.text('ENTREGA',0,62,22);p.text('FECHA ACORDADA ✓',0,101,17);});}
function clock(p:Pen,x:number,y:number,t:number,k=1){p.local(x,y,k,()=>{p.ellipse(0,0,91,91,C.cream);for(let i=0;i<12;i++){const a=i*Math.PI/6;p.line([[Math.sin(a)*72,-Math.cos(a)*72],[Math.sin(a)*80,-Math.cos(a)*80]],C.ink,4);}p.line([[0,0],[Math.sin(t*7)*55,-Math.cos(t*7)*55]],C.ink,6);p.line([[0,0],[Math.sin(t*1.1)*35,-Math.cos(t*1.1)*35]],C.orange,8);p.ellipse(0,0,6,6,C.ink,'');});}

function world(p:Pen,index:number,u:number,t:number){
 const enter=ease(u/.8);const half=ease((u-4.3)/1.5);const floating=Math.sin(t*2.4)*8;
 switch(index){
 case 0:{
  city(p,t,u*48);
  const x=lerp(130,490,ease(u/3));luno(p,{x,y:1210,k:1.2,time:t,walk:1-ease((u-2.5)/.6),expression:u<3?'happy':u<6?'surprised':'worried',tilt:u>7?.12:0});
  if(u>2.8&&u<6.5){const f=ease((u-3)/2);coin(p,500+f*72,1250+f*f*280,.56*(1-f));}
  p.local(811,864,1,()=>{p.box(-155,-182,310,364,C.cream,21);p.text('LOS QUIERO.',0,-133,26);headphones(p,0,-21,1.6);p.text('AUDÍFONOS',0,98,24);p.text('S/89',0,142,24,'#a482a1');});
  if(u>6.5)p.alpha(ease((u-6.5)/.6),()=>bubble(p,365,732,'¿Y ahora?',250));break;
 }
 case 1:{
  room(p,t);p.box(276,1270,236,152,'#b3a0c3',38);luno(p,{x:380,y:1204,k:1.13,time:t,seated:true,typing:u<6,expression:u<4?'happy':'confused',point:.1});desk(p);laptop(p,680,1400,1.08);
  const phrases=['dinero fácil','ganar desde casa','¿sin experiencia?'];
  phrases.forEach((a,i)=>{const f=pop((u-1-i*1.7)/.7);if(f>0)p.local(653+i%2*40,717+i*175+floating*.3,f,()=>searchWindow(p,0,0,a,i===0?'Buscar…':'12.000 resultados',.86));});
  if(u>6){p.text('?',318+Math.sin(t)*8,812,70,C.orange);p.text('?',473,864,46,C.orange);}break;
 }
 case 2:{
  room(p,t);const leave=ease((u-7.5)/2);luno(p,{x:395+leave*200,y:1205-leave*24,k:1.15,time:t,walk:leave*.7,expression:u<6.1?'thinking':'proud',point:u>4?.8:0,tilt:leave*-.09});desk(p);laptop(p,700,1400,.95);
  ['S/500 AL DÍA','¡SIN HACER NADA!','RESULTADOS MÁGICOS'].forEach((txt,i)=>{const f=pop((u-i*.8)/.6)*(1-ease((u-4.1-i*.45)/.4));if(f>0)p.local(545+(i%2?108:-80),715+i*184,f,()=>searchWindow(p,0,0,txt,'demasiado bueno para ser verdad',.94,true));});
  if(u>6)p.alpha(ease((u-6)/.6),()=>badge(p,642,737,'ALGO REAL',1,C.mint));
  break;
 }
 case 3:{
  bakery(p,t);luno(p,{x:lerp(110,440,ease(u/3)),y:1255,k:1.14,time:t,walk:1-ease((u-2.5)/.7),expression:u<5?'confused':'thinking',tilt:Math.sin(u*.8)*.12});
  poster(p,800,1038+floating*.4,.72,0,true);
  if(u>5.7){const f=pop((u-5.7)/.7);bulb(p,433,747,f);p.alpha(ease((u-6)/.5),()=>badge(p,720,510,'¡UNA IDEA!',.8,C.cream));}break;
 }
 case 4:{
  room(p,t);luno(p,{x:286,y:1230,k:1.12,time:t,phone:true,expression:u<6?'thinking':'happy'});desk(p);
  phone(p,713,1009,1.75,1);
  p.local(713,997,1.04,()=>{const f=ease((u-1)/1.2);p.alpha(f,()=>{p.box(-94,-168,188,45,C.orange,8,'');p.text('PAN DE CASA',0,-144,18);});p.local(lerp(-280,0,ease((u-2)/1.2)),lerp(-30,-60,ease((u-2)/1.2)),.9,()=>bread(p,0,0));p.alpha(ease((u-4)/1),()=>p.text('S/2',0,24,49));p.alpha(ease((u-5.2)/1),()=>{p.line([[-80,76],[80,76]],C.orange,3);p.text('CALLE LAS FLORES 25',0,108,12);});});
  if(u>7.3){p.star(902,801,26,C.mint);p.star(525,1204,16,C.orange);}break;
 }
 case 5:{
  bakery(p,t,true);
  luno(p,{x:187,y:1212,k:.85,time:t,role:'mom',expression:'happy',walk:.1*(1-enter)});
  luno(p,{x:478,y:1257,k:1.03,time:t,phone:true,expression:u<4.5?'happy':'confused'});
  luno(p,{x:824,y:1168,k:.98,time:t,role:'baker',expression:u<4?'thinking':'confused',point:.15,crossed:u>4});
  p.box(677,1324,350,80,'#c49388',16);poster(p,610,1272,.32);
  if(u>4.2)p.alpha(ease((u-4.2)/.6),()=>bubble(p,718,639,'¿POR QUÉ DEBERÍA USARLO?',533));
  if(u>6.7){p.text('…',453,796,76,C.ink);}break;
 }
 case 6:{
  room(p,t);luno(p,{x:284,y:1230,k:1.1,time:t,phone:true,expression:u<6?'thinking':'proud',tilt:Math.sin(u)*.045});desk(p);
  const cards=pop((u-1)/.8);poster(p,575,940+floating*.3,.77*cards,0);poster(p,861,940-floating*.3,.77*pop((u-3)/.8),1);
  for(let j=0;j<3;j++)p.local(660+j*85,1261,pop((u-4-j*.35)/.5),()=>p.ellipse(0,0,25,25,[C.orange,C.lav,C.mint][j]));
  if(u>7){p.text('A',574,654,32,C.ink);p.text('B',861,654,32,C.ink);p.alpha(ease((u-7)/.5),()=>badge(p,735,1382,'DOS OPCIONES',.73,C.mint));}break;
 }
 case 7:{
  bakery(p,t,true);luno(p,{x:254,y:1254,k:1.08,time:t,expression:u<4?'happy':'proud',celebrate:u>7?.4:0});luno(p,{x:817,y:1171,k:.98,time:t,role:'baker',expression:u<3?'thinking':'happy',point:.5});
  const selection=ease((u-2)/1);poster(p,516,906,.8,0);p.alpha(1-selection,()=>poster(p,842,832,.53,1));
  if(u>4){const k=pop((u-4)/.7);notebook(p,746,1060,.88*k);badge(p,430,638,'S/15',pop((u-4.6)/.8),C.mint);}
  if(u>7)sparkles(p,t,435,871,8);break;
 }
 case 8:{
  room(p,t);luno(p,{x:367,y:1240,k:1.17,time:t,scratch:u>7,expression:u<3.2?'proud':u<7?'surprised':'happy',tilt:u>7?.13:0});
  coin(p,682,1102,1.5,'15');badge(p,719,1230,'S/15',.75,C.cream);
  if(u>3.2){const f=pop((u-3.2)/.5);p.local(745,776,f,()=>{p.box(-220,-230,440,400,'#eee6ef',30);clock(p,0,-101,u,1);poster(p,-91,75,.3,0,true);poster(p,91,75,.3,1,true);p.text('OTRA CORRECCIÓN…',0,142,23);});}
  if(u>7.5)p.alpha(ease((u-7.5)/.7),()=>badge(p,541,505,'APRENDER LLEVA TIEMPO',1.15,C.mint));break;
 }
 case 9:{
  room(p,t);luno(p,{x:278,y:1230,k:1.1,time:t,phone:true,expression:u<2?'surprised':'happy'});desk(p);
  if(u<4.7){const f=pop((u-.3)/.7);p.local(674,805,f,()=>{p.box(-235,-115,470,230,C.cream,24);p.text('NUEVO MENSAJE',0,-71,24,'#927fa3');p.lines('¿Me haces una invitación?',0,-12,410,29);p.text('Amiga de la familia',0,69,21);});}
  if(u>3){const f=pop((u-3)/.8);invitation(p,749,1020+floating*.2,1.22*f);}
  if(u>7)badge(p,747,1334,'S/10',pop((u-7)/.7),C.mint);break;
 }
 case 10:{
  room(p,t);luno(p,{x:282,y:1243,k:1.1,time:t,expression:u<4?'happy':'proud',celebrate:u>5?.3:0});desk(p);
  const move=ease((u-2.6)/1.8);coin(p,lerp(568,718,move),750,1-move,'15');coin(p,lerp(867,718,move),750,1-move,'10');
  if(u<4.4){p.alpha(1-move,()=>{p.text('S/15',568,845,42);p.text('+',718,756,53);p.text('S/10',867,845,42);});}
  badge(p,718,770,'S/25',pop((u-3.7)/.8)*1.5,C.mint);
  poster(p,570,1190,.69,0);invitation(p,858,1190,.69);
  if(u>7&&u<9.6){const save=ease((u-7)/2.6);coin(p,lerp(718,381,save),lerp(866,1295,save)-Math.sin(save*Math.PI)*70,.8*(1-save));}
  if(u>6.5)sparkles(p,t,715,874,9);break;
 }
 case 11:{
  city(p,t,u*6);luno(p,{x:540,y:1260,k:1.18,time:t,expression:u<7?'happy':'proud',point:u<6.8?.5:0,wave:u>7?1:0});
  const positions=[[225,825],[850,825],[540,526]];
  ['DISEÑO','MANUALIDADES','APOYO ESCOLAR'].forEach((txt,j)=>{const f=pop((u-.5-j*1.55)/.7);if(f<=0)return;const [x,y]=positions[j];p.local(x,y+Math.sin(t*2+j)*6,f,()=>{p.ellipse(0,0,101,101,[C.blue,C.orange,C.mint][j]);
   if(j===0){p.box(-56,-45,112,75,C.cream,10);p.line([[-28,-17],[28,4],[-28,17]],C.lav,10);p.line([[-37,48],[37,48]],C.ink,6);}
   if(j===1){p.line([[-40,37],[39,-42]],C.ink,12);p.line([[-40,-30],[40,40]],C.ink,12);p.ellipse(-42,39,17,20,C.cream,C.ink,5);p.ellipse(-42,-32,17,20,C.cream,C.ink,5);}
   if(j===2){p.path([[-62,-41],[0,-25],[62,-41],[62,42],[0,58],[-62,42]],C.cream);p.line([[0,-23],[0,56]],C.ink,4);}
   p.text(txt,0,139,22,C.ink);
  });});
  break;
 }
 }
}

/** Pure seekable frame renderer, shared by Motion Canvas and offline export. */
export function drawFrame(ctx:CanvasRenderingContext2D,time:number,subtitles=true){
 const t=clamp(time,0,119.99999),index=Math.min(11,Math.floor(t/10)),u=t-index*10;const p=new Pen(ctx);
 ctx.save();ctx.clearRect(0,0,1080,1920);
 // A very slow push and lateral drift on independent world layers.
 const zoom=1+.025*ease(u/10)+.018*Math.sin(Math.PI*ease(u/10));ctx.translate(540,1010);ctx.scale(zoom,zoom);ctx.translate(-540+Math.sin(t*.35)*3,-1010);
 world(p,index,u,t);ctx.restore();
 ctx.save();
 // Editorial overlay stays locked while the world moves.
 const top=ctx.createLinearGradient(0,0,0,465);top.addColorStop(0,'rgba(255,240,221,.98)');top.addColorStop(.83,'rgba(255,240,221,.95)');top.addColorStop(1,'rgba(255,240,221,0)');ctx.fillStyle=top;ctx.fillRect(0,0,1080,465);
 p.box(70,73,173,54,C.ink,27,'');p.text('LUNO',157,100,30,C.cream);p.text('MIS PRIMEROS 25 SOLES',278,101,23,C.ink,700,'left');
 p.text(`${String(index+1).padStart(2,'0')} / 12`,981,102,22,C.ink,700,'right');
 const scene=story.scenes[index],which=u<5?0:1;const headline=scene.headlines[which];
 const anim=pop((u%5)/.45);p.local(540,240+16*(1-anim),.97+.03*anim,()=>p.alpha(anim,()=>p.lines(headline,0,0,924,headline.length>33?43:54,C.ink,1.2)));
 if(index===11&&u>6.5){p.alpha(ease((u-6.5)/.6),()=>badge(p,540,1503,'¿CON CUÁL EMPEZARÍAS?',1.55,C.cream));}
 if(subtitles){const cue=story.subtitles.find(q=>t>=q.start&&t<q.end);if(cue){
  const fade=Math.min(ease((t-cue.start)/.13),ease((cue.end-t)/.12));p.alpha(fade,()=>{
   p.box(59,1645,962,179,C.ink,29,'');p.lines(cue.text,540,1693,871,33,C.cream,1.3);
  });
 }}
 p.box(71,1866,938,5,'#c5abc1',2,'');p.box(71,1866,938*t/120+.01,5,C.ink,2,'');
 p.text('UNA HISTORIA SOBRE EMPEZAR',540,1901,15,'#70566f');
 // Soft pastel swipes at the cut, never interrupt the narration.
 if(u<.25&&index>0){const f=1-ease(u/.25);p.alpha(f*.36,()=>p.box(0,0,1080,1920,C.cream,0,''));}
 if(t>119){p.alpha(ease(t-119),()=>p.box(0,0,1080,1920,C.ink,0,''));}
 ctx.restore();
}
