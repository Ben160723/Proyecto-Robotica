import {Node,makeScene2D} from '@motion-canvas/2d';
import {createSignal,tween,linear} from '@motion-canvas/core';
import {drawFrame} from './animation';
export class LunoStage extends Node {
  public readonly playhead=createSignal(0);
  protected override draw(context:CanvasRenderingContext2D){
    context.save();context.translate(-540,-960);drawFrame(context,this.playhead());context.restore();
  }
}
export function lunoScene(index:number){
  // Motion Canvas includes the terminal frame of each generator. Reserve it
  // here so that each scene is exactly 300 frames at the project's 30 FPS.
  return makeScene2D(function*(view){const stage=new LunoStage({});view.add(stage);stage.playhead(index*10);const duration=10-1/30;yield* tween(duration,t=>stage.playhead(index*10+t*duration),linear);});
}
