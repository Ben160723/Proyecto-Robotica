import fs from 'node:fs';
import path from 'node:path';
const SR=24000,DURATION=120,N=SR*DURATION,channels=2;
const music=new Float32Array(N*2),sfx=new Float32Array(N*2),guide=new Float32Array(N*2);
type Kind='bell'|'pluck'|'kick'|'noise'|'coin'|'comic'|'step'|'click';
const cues:{time:number;kind:string;description:string}[]=[];
let seed=25;const random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
function tone(dst:Float32Array,at:number,duration:number,hz:number,amp:number,kind:Kind='pluck',pan=0){
 const start=Math.floor(at*SR),count=Math.floor(duration*SR);
 for(let j=0;j<count;j++){const index=start+j;if(index<0||index>=N)continue;const t=j/SR;const attack=Math.min(1,t/.008),release=Math.min(1,(duration-t)/.04);let v=0;
  if(kind==='noise'||kind==='step'||kind==='click')v=(random()*2-1)*Math.exp(-t*(kind==='step'?30:75));
  else if(kind==='kick')v=Math.sin(2*Math.PI*(45*t+1.6*(1-Math.exp(-t*25))))*Math.exp(-t*20);
  else if(kind==='comic')v=Math.sin(2*Math.PI*(hz*t-110*t*t))*Math.exp(-t*4);
  else if(kind==='coin')v=(Math.sin(t*hz*2*Math.PI)+.3*Math.sin(t*hz*3.15*2*Math.PI))*Math.exp(-t*11);
  else v=(Math.sin(2*Math.PI*hz*t)+.2*Math.sin(2*Math.PI*hz*2*t))*Math.exp(-t*(kind==='bell'?3:8));
  v*=amp*attack*release;dst[index*2]+=v*(1-pan*.35);dst[index*2+1]+=v*(1+pan*.35);
 }
}
const minor=[220,261.63,329.63,392,329.63,261.63,246.94,293.66];
const major=[261.63,329.63,392,523.25,293.66,349.23,440,587.33];
for(let i=0;i<280;i++){const at=i*60/108/2;if(at>=120)break;const hopeful=at>=36;const melody=hopeful?major:minor;const note=melody[(i+Math.floor(i/16))%8];
 tone(music,at,.4,note,at<30?.045:.056,'pluck',Math.sin(i*.8)*.5);
 if(i%2===0)tone(music,at,.25,55,.07,'kick');if(i%4===2)tone(music,at,.12,1,.018,'noise',-.2);
 if(i%8===0){tone(music,at,1.5,note/2,.027,'bell');tone(music,at,1.2,note*.75,.016,'bell');}
}
function effect(time:number,kind:Kind,description:string){cues.push({time,kind,description});
 if(kind==='bell'){tone(sfx,time,.8,1046.5,.13,'bell');tone(sfx,time+.12,.9,1318.5,.08,'bell');}
 else if(kind==='coin'){for(let j=0;j<3;j++)tone(sfx,time+j*.09,.35,1300+j*350,.105,'coin');}
 else if(kind==='comic')tone(sfx,time,.55,340,.14,'comic');
 else if(kind==='step')tone(sfx,time,.12,1,.09,'step');
 else if(kind==='click')tone(sfx,time,.05,1,.08,'click');
 else tone(sfx,time,.18,1,.075,'noise');
}
for(const at of [1,1.45,1.9,2.35,30.9,31.35,31.8,50.7,51.1])effect(at,'step','paso suave');
for(const at of [4,7,56.5,83.3,87.4])effect(at,'comic','bolsillo vacío / pausa cómica / recuerdo');
for(const start of [11,12.7,14.4,41,42,43,44,46,61,62,63,64,66,94,95,96])for(let j=0;j<4;j++)effect(start+j*.105,'click','teclado / toque digital');
for(const at of [21,21.8,22.6]){tone(sfx,at,.23,494,.075,'bell');cues.push({time:at,kind:'alerta',description:'ventana sospechosa'});}
for(const at of [24.1,24.55,25])effect(at,'click','cerrar ventana');
for(const at of [32,50,70])effect(at,'bell','campanilla de panadería');
for(const at of [35.7,47.4,67,74.6,97,103.7])effect(at,'bell','idea o confirmación');
for(const at of [74.7,80.4,97.2,103.8])effect(at,'coin','monedas');
for(let j=0;j<18;j++)effect(83.7+j*.14,'click','tic-tac acelerado');
for(const at of [90.3,110.5,112.05,113.6]){tone(sfx,at,.3,784,.1,'bell');tone(sfx,at+.1,.4,1047,.07,'bell');cues.push({time:at,kind:'notificación',description:'mensaje o aparición de icono'});}
for(let sc=1;sc<12;sc++){tone(sfx,sc*10,.15,1,.03,'noise');cues.push({time:sc*10,kind:'transición',description:'barrido suave'});}
for(let sc=0;sc<12;sc++)for(let j=0;j<3;j++)tone(guide,sc*10+j*.125,.07,j===2?1046:784,.14,'bell');
const mix=new Float32Array(N*2);for(let i=0;i<N*2;i++){const time=i/2/SR,fade=Math.min(1,time/.5,(120-time));music[i]*=Math.max(0,fade);sfx[i]*=Math.min(1,Math.max(0,120-time));mix[i]=music[i]+sfx[i];guide[i]+=mix[i]*.45;}
function wav(file:string,data:Float32Array){let peak=0;for(const v of data)peak=Math.max(peak,Math.abs(v));const scale=peak>.92?.92/peak:1;const b=Buffer.alloc(44+data.length*2);b.write('RIFF',0);b.writeUInt32LE(b.length-8,4);b.write('WAVEfmt ',8);b.writeUInt32LE(16,16);b.writeUInt16LE(1,20);b.writeUInt16LE(channels,22);b.writeUInt32LE(SR,24);b.writeUInt32LE(SR*channels*2,28);b.writeUInt16LE(channels*2,32);b.writeUInt16LE(16,34);b.write('data',36);b.writeUInt32LE(data.length*2,40);for(let i=0;i<data.length;i++)b.writeInt16LE(Math.round(Math.max(-1,Math.min(1,data[i]*scale))*32767),44+i*2);fs.writeFileSync(file,b);console.log(path.basename(file),'peak',peak.toFixed(3));}
fs.mkdirSync('public/audio',{recursive:true});wav('public/audio/musica-original.wav',music);wav('public/audio/efectos.wav',sfx);wav('public/audio/mix.wav',mix);wav('public/audio/guia-sin-voz.wav',guide);fs.writeFileSync('public/audio/cues.json',JSON.stringify(cues.sort((a,b)=>a.time-b.time),null,2));
