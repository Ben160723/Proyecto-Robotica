import fs from 'node:fs';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import story from '../src/story.json';
const report:{[key:string]:unknown}={checkedAt:new Date().toISOString(),spokenVoice:false,subtitleCues:story.subtitles.length,scenes:story.scenes.length};
const videos=[];
for(const [file,w,h]of [['exports/luno-25-soles-1080p.mp4',1080,1920],['exports/luno-25-soles-preview.mp4',540,960]] as const){
 const result=spawnSync('ffprobe',['-v','error','-count_frames','-show_entries','format=duration,size:stream=codec_name,codec_type,width,height,r_frame_rate,nb_read_frames,duration','-of','json',file],{encoding:'utf8'});
 assert.equal(result.status,0,result.stderr);const info=JSON.parse(result.stdout);const v=info.streams.find((s:any)=>s.codec_type==='video'),a=info.streams.find((s:any)=>s.codec_type==='audio'),s=info.streams.find((s:any)=>s.codec_type==='subtitle');
 assert.equal(v.width,w);assert.equal(v.height,h);assert.equal(v.r_frame_rate,'30/1');assert.equal(Number(v.nb_read_frames),3600);assert.equal(Number(info.format.duration),120);assert.equal(Number(a.duration),120);assert.equal(s.codec_name,'mov_text');
 const decoded=spawnSync('ffmpeg',['-v','error','-i',file,'-map','0:v','-map','0:a','-f','null','-'],{encoding:'utf8'});assert.equal(decoded.status,0,decoded.stderr);assert.equal(decoded.stderr,'');
 videos.push({file,...info,decodePassed:true,sha256:createHash('sha256').update(fs.readFileSync(file)).digest('hex')});
}
for(const s of story.scenes){const cues=story.subtitles.filter(c=>c.scene===s.index);assert.equal(cues.map(c=>c.text).join(' '),s.narration);assert(cues.every(c=>c.start>=s.start&&c.end<=s.end));}
report.videos=videos;report.narrationPreservedVerbatim=true;fs.writeFileSync('exports/verificacion.json',JSON.stringify(report,null,2));console.log('PASS: both videos decoded, exactly 120 s / 3600 frames, correct dimensions, AAC audio, SRT track, 12 complete narrative scenes.');
