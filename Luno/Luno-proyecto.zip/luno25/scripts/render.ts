import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {createCanvas,GlobalFonts} from '@napi-rs/canvas';
import {drawFrame,WIDTH,HEIGHT,FPS,DURATION} from '../src/animation';
GlobalFonts.registerFromPath('public/fonts/DejaVuSans.ttf','LunoSans');
GlobalFonts.registerFromPath('public/fonts/DejaVuSans-Bold.ttf','LunoSans');
const preview=process.argv.includes('--preview');const snapshots=process.argv.includes('--stills');
const width=preview?540:WIDTH,height=preview?960:HEIGHT;
const canvas=createCanvas(width,height);const context=canvas.getContext('2d');
context.scale(width/WIDTH,height/HEIGHT);
fs.mkdirSync('exports/stills',{recursive:true});
for(let scene=0;scene<12;scene++)for(const offset of [2.5,7.5]){drawFrame(context as unknown as CanvasRenderingContext2D,scene*10+offset);fs.writeFileSync(`exports/stills/scene-${String(scene+1).padStart(2,'0')}-${offset}.jpg`,canvas.toBuffer('image/jpeg',85));}
if(snapshots)process.exit(0);
const name=preview?'luno-25-soles-preview.mp4':'luno-25-soles-1080p.mp4';const out=path.join('exports',name);
const args=['-y','-v','warning','-f','rawvideo','-pixel_format','rgba','-video_size',`${width}x${height}`,'-framerate',String(FPS),'-i','pipe:0','-i','public/audio/mix.wav','-i','exports/luno.srt','-map','0:v','-map','1:a','-map','2:s','-c:v','libx264','-preset','fast','-crf',preview?'23':'20','-threads','4','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-c:s','mov_text','-metadata:s:s:0','language=spa','-t',String(DURATION),'-movflags','+faststart',out];
const ff=spawn('ffmpeg',args,{stdio:['pipe','inherit','inherit']});
ff.on('error',error=>{console.error('FFmpeg is required:',error.message);process.exitCode=1;});
const finished=new Promise<void>((resolve,reject)=>ff.on('close',code=>code===0?resolve():reject(new Error(`FFmpeg exited ${code}`))));
const begin=Date.now();
for(let i=0;i<FPS*DURATION;i++){
 drawFrame(context as unknown as CanvasRenderingContext2D,i/FPS);
 const rgba=canvas.data();if(!ff.stdin.write(rgba))await once(ff.stdin,'drain');
 if(i%300===0)console.log(`${name}: ${(i/(FPS*DURATION)*100).toFixed(0)}% · ${Math.round((Date.now()-begin)/1000)}s elapsed`);
}
ff.stdin.end();await finished;console.log('Exported',out,fs.statSync(out).size,'bytes');
