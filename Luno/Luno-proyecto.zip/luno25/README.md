# LUNO — MIS PRIMEROS 25 DÓLARES

Historia animada original de **120 segundos, 1080 × 1920, 30 FPS**. La narración de las doce escenas está adaptada a dólares, como solicitó el usuario. El título refleja el total de $15 + $10; el primer encargo sigue siendo de quince dólares.

## Ver el resultado

- `exports/luno-25-dolares-1080p.mp4`: video final H.264/AAC; 3.600 fotogramas, 120 s.
- `exports/luno-25-dolares-preview.mp4`: versión ligera, 540 × 960.
- `exports/luno.srt`: narración completa, en español, dividida por frases y sincronizada por escena.
- `exports/guia-de-narracion.txt`: texto con sus intervalos de grabación.
- `public/audio/guia-sin-voz.wav`: pista guía. Tres señales al principio de cada escena; la tercera marca aproximadamente el comienzo de la lectura.
- `public/audio/musica-original.wav`, `efectos.wav`, `mix.wav`: música original, efectos y mezcla, separados para editar.

**Esta entrega no contiene una voz hablada.** El guion permitía sustituirla por SRT y pista guía. El MP4 incluye música, efectos y únicamente los textos de la parte superior. Se quitaron los subtítulos inferiores y la pista seleccionable para evitar duplicados. El archivo SRT se entrega por separado como referencia para una futura narración; no está incrustado en el video.

## Ejecutarlo en Windows

1. Descomprime todo el proyecto en una carpeta local.
2. Instala Node.js 22 o superior y FFmpeg con `ffmpeg` y `ffprobe` en el PATH. Una opción en PowerShell es `winget install OpenJS.NodeJS.LTS` y `winget install Gyan.FFmpeg`. Cierra y abre PowerShell después.
3. Abre PowerShell en la carpeta del proyecto y ejecuta:

```powershell
npm ci
npm run start
```

Abre la dirección local que imprima Vite. El editor de Motion Canvas muestra las doce escenas, permite recorrer la línea de tiempo y reproducir el audio. La resolución y la frecuencia ya están guardadas en `src/project.meta`. Espera a que las fuentes carguen antes de exportar desde el editor.

Para volver a producir los archivos sin depender de la velocidad de reproducción del navegador:

```powershell
npm run typecheck
npm run audio
npm run render
npm run preview:render
npm run verify
```

La exportación utiliza el mismo dibujante vectorial TypeScript que el nodo de Motion Canvas, mediante un lienzo nativo y FFmpeg. No es una grabación de pantalla. No requiere imágenes intermedias ni una GPU. La pista de voz no se sintetiza automáticamente.

Para comprobar la compilación del proyecto editable: `npm run build`.

## Añadir una narración MP3

Graba las doce frases siguiendo `exports/luno.srt`: una escena cada diez segundos. Puedes importar el MP3 en tu editor y colocar cada frase con ayuda de `guia-sin-voz.wav`. No grabes las señales de la guía dentro de la narración.

Para una narración que **ya esté sincronizada desde el segundo cero**, ejecuta:

```powershell
npm run voice -- "C:\Audios\narracion.mp3"
```

Esto genera `exports/luno-25-dolares-con-voz.mp4`. Conserva la velocidad de la voz, reduce música y efectos al 25 % y aplica un limitador. Si el audio supera los 120 segundos, se rechaza: no se cortan palabras ni se acelera automáticamente. Si es más corto, se completa con silencio. El programa no alinea automáticamente palabras de una grabación continua sin pausas.

Para oír la voz también en Motion Canvas, copia tu MP3 a `public/audio/narracion.mp3` y cambia la propiedad `audio` de `src/project.ts` a `/audio/narracion.mp3`; para conservar música y voz en el editor puedes extraer antes la mezcla del video con voz usando FFmpeg.

## Estructura y edición

| Archivo | Función |
| --- | --- |
| `src/art.ts` | Personaje articulado, expresiones, formas y objetos reutilizables. |
| `src/animation.ts` | Escenarios, acciones independientes, cámara, textos y las doce composiciones. |
| `src/story.json` | Narración literal, intervalos y titulares. |
| `src/stage.ts` | Nodo reutilizable y generador de escenas de Motion Canvas. |
| `src/scenes/` | Doce escenas individuales de 300 fotogramas. |
| `scripts/audio.ts` | Síntesis determinista de música y efectos, con lista de eventos en `public/audio/cues.json`. |
| `scripts/render.ts` | Exportación final, vista previa y fotogramas de revisión. |
| `scripts/voice.ts` | Importación de narración sin alterar su velocidad. |
| `reference/` | Diseño aprobado de Luno y guion entregado. |

Luno mantiene los mismos colores y proporciones: cabeza marfil, ojos pequeños, sudadera azul, bolsillo, bandolera naranja, extremidades oscuras y zapatillas claras. El personaje se redibujó como geometría articulada; la imagen de referencia no se usa como diapositiva. Incluye estados feliz, confundido, preocupado, sorprendido, pensativo y orgulloso; ciclos de caminata, gestos, mirada al celular, brazos articulados, parpadeos y saludos. La madre y la panadera son variantes secundarias con colores y tamaños diferentes.

Todo se dibuja por capas y se calcula a partir del tiempo absoluto: se puede saltar a cualquier punto sin perder el estado. No hay simulación aleatoria no reproducible. Los fondos, ventanas, carteles, moneda, teléfono, libreta y reloj son objetos independientes. Los cortes duran exactamente diez segundos; hay varios cambios de objetos, gestos y textos dentro de cada escena.

Música y efectos se sintetizaron para este proyecto, sin grabaciones de terceros. Las fuentes DejaVu incluyen su licencia en `public/fonts/LICENSE.txt`.

## Comprobaciones realizadas

Consulta `exports/verificacion.json` para los resultados de esta entrega. La validación se realizó en Linux; los comandos de Windows se proporcionan para reproducción, pero no se ejecutaron en Windows. El editor puede solicitar fuentes auxiliares de su propia interfaz a servicios externos; las fuentes del video están incluidas localmente.
